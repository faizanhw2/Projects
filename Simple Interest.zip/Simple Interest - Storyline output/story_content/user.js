function ExecuteScript(strId)
{
  switch (strId)
  {
      case "677XHnaRhIk":
        Script1();
        break;
  }
}

function Script1()
{
  JavaScript code:
let player = GetPlayer();
let principalAmountExternal = player.GetVar("principalAmount");
let interestRateExternal = player.GetVar("rateOfInterest");
let yearExternal = player.GetVar("year");
let simpleInterestExternal = (principalAmountExternal * yearExternal * interestRateExternal) / 100;
player.SetVar("simpleInterest", simpleInterestExternal);

}

