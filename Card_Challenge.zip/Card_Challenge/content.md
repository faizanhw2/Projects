H2
PERFUME

H1 
Gabrielle Essence Eau De Parfum

PARAGRAPH
A floral, solar and voluptuous interpretation composed by Olivier Polge, Perfumer-Creator for the House of CHANEL.

BUTTON
Add to Cart